# Deep Learning Models

1. CBOW folder: [The Tensorflow version of the CBOW model.](https://github.com/edwardbi/DeepLearningModels/tree/master/CBOW)
2. DM folder: [The Gensim and Tensorflow versions of DM model.](https://github.com/edwardbi/DeepLearningModels/tree/master/DM)
3. RCNN folder: [The Tensorflow with tflearn version of the RCNN model.](https://github.com/edwardbi/DeepLearningModels/tree/master/RCNN)
